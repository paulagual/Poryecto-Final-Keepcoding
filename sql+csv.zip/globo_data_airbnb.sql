-- importar el archivo airbnblistingsimport.csv a la tabla list del esquema public, en adelante public.list: 

create table public.list(
	id varchar (9) not null,
	"Listing Url" text not null, 
	"Scrape ID" bigint not null, 
	"Last Scraped" date, 
	"Name" text not null, 
	summary text, 
	"Space" text,
	description text, 
	"Experiences Offered" text, 
	"Neighborhood Overview" varchar,
	notes text, 
	transit text, 
	"Access" text, 
	interaction text, 
	"House Rules" text, 
	"Thumbnail Url" text, 
	"Medium Url" text, 
	"Picture Url" text, 
	"XL Picture Url" text, 
	"Host ID" varchar (20) not null, 
	"Host URL" text, 
	"Host Name" varchar (40) not null,
	"Host Since" date, 
	"Host Location" varchar, 
	"Host About" text, 
	"Host Response Time" text, 
	"Host Response Rate" int, 
	"Host Acceptance Rate" int, 
	"Host Thumbnail Url" text not null, 
	"Host Picture Url" text not null, 
	"Host Neighbourhood" varchar, 
	"Host Listings Count" int, 
	"Host Total Listings Count" int, 
	"Host Verifications" varchar not null, 
	street varchar not null, 
	neighbourhood varchar, 
	"Neighbourhood Cleansed" varchar, 
	"Neighbourhood Group Cleansed" varchar, 
	city varchar (40) not null, 
	state varchar, 
	zipcode varchar (20), 
	market varchar (40) not null, 
	"Smart Location" varchar (60) not null, 
	"Country Code" varchar (2) not null, 
	country varchar (20) not null, 
	latitude varchar not null, 
	longitude varchar not null, 
	"Property Type" varchar (50) not null, 
	"Room Type" varchar(50) not null, 
	accommodates int not null, 
	bathrooms int, 
	bedrooms int, 
	beds int, 
	"Bed Type" varchar(50) not null,
	amenities varchar not null, 
	"Square Feet" int, 
	price money not null, 
	"Weekly Price" money, 
	"Monthly Price" money, 
	"Security Deposit" money,
	"Cleaning Fee" money, 
	"Guests Included" int not null, 
	"Extra People" money, 
	"Minimum Nights" int not null, 
	"Maximum Nights" int not null, 
	"Calendar Updated" varchar not null, 
	"Has Availability"varchar, 
	"Availability 30" int, 
	"Availability 60" int, 
	"Availability 90" int, 
	"Availability 365" int, 
	"Calendar last Scraped" date not null, 
	"Number of Reviews" int, 
	"First Review" date, 
	"Last Review" date, 
	"Review Scores Rating" int, 
	"Review Scores Accuracy" int, 
	"Review Scores Cleanliness" int, 
	"Review Scores Checkin" int, 
	"Review Scores Communication" int, 
	"Review Scores Location" int, 
	"Review Scores Value" int, 
	license varchar, 
	"Jurisdiction Names" varchar, 
	"Cancellation Policy" varchar (20) not null, 
	"Calculated host listings count" int, 
	"Reviews per Month" numeric, 
	geolocation varchar (50) not null, 
	features varchar not null
);

--crear el esquema

create schema globo_data_airbnb authorization juqvisgw;


--crear tablas en función del diagrama E-R

create table globo_data_airbnb.property(
	ID_PROPERTY varchar (9) not null,
	"Host ID" varchar (20) not null,
	"Name" text not null, 
	summary text, 
	"Space" text,
	description text, 
	"Experiences Offered" text, 
	"Neighborhood Overview" varchar,
	notes text, 
	transit text, 
	"Access" text, 
	interaction text, 
	"House Rules" text, 
	"Property Type" varchar (50) not null, 
	"Square Feet" int,
	"Neighbourhood Group Cleansed" varchar,
	price money not null, 
	"Weekly Price" money, 
	"Monthly Price" money, 
	"Security Deposit" money,
	"Cleaning Fee" money,
	amenities varchar not null, 
	"Guests Included" int not null, 
	"Extra People" money, 
	"Number of Reviews" int,
	"Review Scores Rating" int, 
	"Reviews per Month" numeric, 
	"Review Scores Accuracy" int, 
	"Review Scores Cleanliness" int, 
	"Review Scores Checkin" int, 
	"Review Scores Communication" int, 
	"Review Scores Location" int, 
	"Review Scores Value" int,
	"Cancellation Policy" varchar (20) not null, 
	"Minimum Nights" int not null, 
	"Maximum Nights" int not null
);

create table globo_data_airbnb.property_type(
	"Property Type" varchar (50) not null,
	ID_PROPERTY varchar (9) not null,
	"Room Type" varchar(50) not null, 
	accommodates int not null, 
	bathrooms int, 
	bedrooms int, 
	beds int, 
	"Bed Type" varchar(50) not null
);

create table globo_data_airbnb.host(
	"Host ID" varchar (20) not null,
	ID_PROPERTY varchar (9) not null, 
	"Host Name" varchar (40) not null,
	"Host About" text,
	"Host Since" date, 
	"Host Response Time" text, 
	"Host Response Rate" int, 
	"Host Total Listings Count" int
);

create table globo_data_airbnb.location(
	ID_PROPERTY varchar (9) not null,
	zipcode varchar (20),
	"Neighbourhood Group Cleansed" varchar, 
	city varchar (40) not null, 
	country varchar (20) not null, 
	latitude varchar not null, 
	longitude varchar not null
);

--importamos los datos de la tabla public.list a la base de datos

insert into globo_data_airbnb.property
(ID_PROPERTY,"Host ID","Name",summary,"Space",description,"Experiences Offered","Neighborhood Overview",notes,transit,"Access",interaction,"House Rules","Property Type","Square Feet","Neighbourhood Group Cleansed",price,"Weekly Price","Monthly Price","Security Deposit","Cleaning Fee",amenities,"Guests Included","Extra People","Number of Reviews",	"Review Scores Rating","Reviews per Month","Review Scores Accuracy","Review Scores Cleanliness","Review Scores Checkin","Review Scores Communication", "Review Scores Location","Review Scores Value","Cancellation Policy", "Minimum Nights","Maximum Nights")
select id,"Host ID","Name",summary,"Space",description,"Experiences Offered","Neighborhood Overview",notes,transit,"Access",interaction,"House Rules","Property Type","Square Feet","Neighbourhood Group Cleansed",price,"Weekly Price","Monthly Price","Security Deposit","Cleaning Fee",amenities,"Guests Included","Extra People","Number of Reviews",	"Review Scores Rating","Reviews per Month","Review Scores Accuracy","Review Scores Cleanliness","Review Scores Checkin","Review Scores Communication", "Review Scores Location","Review Scores Value","Cancellation Policy", "Minimum Nights","Maximum Nights"
from public.list;

insert into globo_data_airbnb.property_type
("Property Type",ID_PROPERTY,"Room Type",accommodates,bathrooms,bedrooms,beds,"Bed Type")
select "Property Type",id,"Room Type",accommodates,bathrooms,bedrooms,beds,"Bed Type"
from public.list;

insert into globo_data_airbnb.host
("Host ID",ID_PROPERTY, "Host Name","Host About", "Host Since", "Host Response Time","Host Response Rate", "Host Total Listings Count")
select "Host ID",id, "Host Name","Host About", "Host Since", "Host Response Time","Host Response Rate", "Host Total Listings Count"
from public.list;

insert into globo_data_airbnb.location
(ID_PROPERTY,zipcode,"Neighbourhood Group Cleansed", city, country, latitude, longitude) 
select id,zipcode,"Neighbourhood Group Cleansed", city, country, latitude, longitude 
from public.list;


--pk/fk
alter table globo_data_airbnb.property add constraint property_PK primary key (ID_PROPERTY);
alter table globo_data_airbnb.location add constraint location_id_PK primary key(ID_PROPERTY);
alter table globo_data_airbnb.property_type add constraint property_type_PK primary key(ID_PROPERTY);
alter table globo_data_airbnb.host add constraint host_PK primary key(ID_PROPERTY);
alter table globo_data_airbnb.location add constraint location_id_FK foreign key (ID_PROPERTY) references globo_data_airbnb.property(ID_PROPERTY);
alter table globo_data_airbnb.property_type add constraint property_type_id_FK foreign key (ID_PROPERTY) references globo_data_airbnb.property(ID_PROPERTY);
alter table globo_data_airbnb.host add constraint host_id_fk foreign key (ID_PROPERTY) references globo_data_airbnb.property(ID_PROPERTY);